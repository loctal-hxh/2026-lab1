@echo OFF
rem This bat file check if PacketTracer is installed and add firewall rule for block any trafiic from application
net session nul 2&1
if %errorLevel% == 0 (
		echo Success Administrative permissions confirmed.
) else (
        echo Error Try again with Administrator access!
		pause
		exit
)
echo Firewall must be turn on for this PT hack
netsh advfirewall show allprofiles state
IF EXIST %PT7HOME%binPacketTracer7.exe netsh advfirewall firewall add rule name=PT7_BlockTraffic dir=out program=%PT7HOME%binPacketTracer7.exe profile=any action=block
IF EXIST %PT8HOME%binPacketTracer.exe netsh advfirewall firewall add rule name=PT8_BlockTraffic dir=out program=%PT8HOME%binPacketTracer.exe profile=any action=block
pause